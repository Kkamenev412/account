<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <a href="<?php echo e(route('accesses')); ?>"><button type="button" class="btn btn-warning"><i class="bi bi-plus-square"></i> Добавить проект</button></a>
     <?php $__env->endSlot(); ?>
    <div class="container py-5">
        <?php if(session('success')): ?>
            <div class="alert alert-success" style="margin-top: 10px">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    <h3>Проекты</h3>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-light p-5 rounded mt-3">
                <h3><?php echo e($el->title); ?></h3>
                <div> <b class="">FTP</b><br> <?php echo e($el->ftp); ?></div>
                <div> <b class="">Хогстинг</b><br> <?php echo e($el->host); ?></div>
                <div> <b class="">Дополнительная иинформация</b><br> <?php echo e($el->information); ?></div>
                <div> <smal><?php echo e($el->created_at); ?></smal></div>
                <hr>

                <a href="<?php echo e(route('acceesses-update', $el->id)); ?>"><button class="btn btn-primary">Редактировать</button> </a>
                <a href="<?php echo e(route('acceesses-delite', $el->id)); ?>"><button class="btn btn-danger">Удалить</button> </a>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\accesses\resources\views/dashboard.blade.php ENDPATH**/ ?>