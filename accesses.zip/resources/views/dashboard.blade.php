<x-app-layout>
    <x-slot name="header">
        <a href="{{route('accesses')}}"><button type="button" class="btn btn-warning"><i class="bi bi-plus-square"></i> Добавить проект</button></a>
    </x-slot>
    <div class="container py-5">
        @if(session('success'))
            <div class="alert alert-success" style="margin-top: 10px">
                {{session('success')}}
            </div>
        @endif
    <h3>Проекты</h3>
        @foreach($data as $el)
            <div class="bg-light p-5 rounded mt-3">
                <h3>{{ $el->title }}</h3>
                <div> <b class="">FTP</b><br> {{ $el->ftp }}</div>
                <div> <b class="">Хогстинг</b><br> {{ $el->host }}</div>
                <div> <b class="">Дополнительная иинформация</b><br> {{ $el->information }}</div>
                <div> <smal>{{$el->created_at}}</smal></div>
                <hr>

                <a href="{{route('acceesses-update', $el->id)}}"><button class="btn btn-primary">Редактировать</button> </a>
                <a href="{{route('acceesses-delite', $el->id)}}"><button class="btn btn-danger">Удалить</button> </a>

            </div>

        @endforeach
    </div>
</x-app-layout>
