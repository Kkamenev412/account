<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <a href="<?php echo e(route('accesses')); ?>"><button type="button" class="btn btn-warning"><i class="bi bi-plus-square"></i> Добавить проект</button></a>
     <?php $__env->endSlot(); ?>
    <div class="container py-5">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
            <form action="<?php echo e(route('submit-update', $data->id)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-6 py-3">
                        <div class="form-group">
                            <label for="title" class="form-label">Название проекта</label>
                            <input type="text" name="title"class="form-control" value="<?php echo e($data->title); ?>" placeholder="Введите имя" id="title" class="form-control">
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="host" class="form-label">Хостинг</label>
                            <textarea name="host" class="form-control" id="host" cols="20" rows="6"><?php echo e($data->host); ?></textarea>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="ftp" class="form-label">FTP</label>
                            <textarea name="ftp" id="ftp" cols="30" class="form-control" rows="6"><?php echo e($data->ftp); ?></textarea>
                        </div>
                    </div>

                    <div class="col-6 py-3">

                        <div class="form-group">
                            <label for="information" class="form-label">Дополнительная информация</label>
                            <textarea name="information" class="form-control" id="information" cols="30" rows="12"><?php echo e($data->information); ?></textarea>
                        </div>
                    </div>

                </div>

                <br>
                <button type="submit" class="btn btn-success">Обновить</button>

            </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/u1059176/data/www/proger.centr.one/resources/views/acceesses-update.blade.php ENDPATH**/ ?>