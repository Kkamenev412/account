<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <a href="<?php echo e(route('accesses')); ?>"><button type="button" class="btn btn-warning"><i class="bi bi-plus-square"></i> Добавить проект</button></a>
     <?php $__env->endSlot(); ?>
    <div class="container py-5">
        <?php if(session('success')): ?>
            <div class="alert alert-success" style="margin-top: 10px">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    <h3>Проекты</h3>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-light p-5 rounded mt-3">
                <h3><?php echo e($el->title); ?></h3>

                <div> <smal><?php echo e($el->created_at); ?></smal></div>
                <hr>

                <a href="<?php echo e(route('acceesses-features', $el->id)); ?>"><button class="btn btn-warning"><i class="bi bi-folder2-open"></i></button> </a>
                <a href="<?php echo e(route('acceesses-update', $el->id)); ?>"><button class="btn btn-primary"><i class="bi bi-pencil-square"></i></button> </a>
                <a href="<?php echo e(route('acceesses-delite', $el->id)); ?>"><button class="btn btn-danger"><i class="bi bi-cart-x-fill"></i></button> </a>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/u1059176/data/www/proger.centr.one/resources/views/dashboard.blade.php ENDPATH**/ ?>